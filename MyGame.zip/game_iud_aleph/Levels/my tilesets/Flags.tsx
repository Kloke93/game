<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="Flags" tilewidth="51" tileheight="140" tilecount="9" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="51" height="140" source="../graphics/Flag/Flag 01.png"/>
 </tile>
 <tile id="1">
  <image width="51" height="140" source="../graphics/Flag/Flag 01.png"/>
 </tile>
 <tile id="2">
  <image width="51" height="140" source="../graphics/Flag/Flag 03.png"/>
 </tile>
 <tile id="3">
  <image width="51" height="140" source="../graphics/Flag/Flag 04.png"/>
 </tile>
 <tile id="4">
  <image width="51" height="140" source="../graphics/Flag/Flag 05.png"/>
 </tile>
 <tile id="5">
  <image width="51" height="140" source="../graphics/Flag/Flag 06.png"/>
 </tile>
 <tile id="6">
  <image width="51" height="140" source="../graphics/Flag/Flag 07.png"/>
 </tile>
 <tile id="7">
  <image width="51" height="140" source="../graphics/Flag/Flag 08.png"/>
 </tile>
 <tile id="8">
  <image width="51" height="140" source="../graphics/Flag/Flag 09.png"/>
 </tile>
</tileset>

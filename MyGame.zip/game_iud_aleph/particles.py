import pygame
from support import import_folder


class ParticleEffect(pygame.sprite.Sprite):

    def __init__(self, member_groups, pos, particle_type):
        super().__init__(member_groups)
        self.frame_index = 0
        self.animation_speed = 0.5
        if particle_type == "jump":
            self.frames = import_folder("Levels/graphics/Dust Particles/Jump")
        elif particle_type == "land":
            self.frames = import_folder("Levels/graphics/Dust Particles/Fall")
        # Scaling frames
        self.frames = [pygame.transform.scale(image, (image.get_width() * 1.6, image.get_height() * 1.6))
                       for image in self.frames]
        self.image = self.frames[self.frame_index]
        self.rect = self.image.get_rect(center=pos)

    def animate(self):
        """ aah """
        self.frame_index += self.animation_speed
        if self.frame_index >= len(self.frames):
            self.kill()
        else:
            self.image = self.frames[int(self.frame_index)]

    def update(self, *args):
        self.animate()

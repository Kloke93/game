"""
Author: Tomas Dal Farra
Date:
Description:
"""
import socket
import time
import pygame
import sys
from settings import WINDOW_WIDTH, WINDOW_HEIGHT, FPS
from level import Level
from menu import MainMenu, WaitingMenu, EndingMenu


class Game:
    def __init__(self, client):
        """ Game and client setup """
        pygame.display.set_caption('Happy Toad')
        self.screen = pygame.display.get_surface()
        self.clock = pygame.time.Clock()
        self.font_name = "Levels/graphics/GameFont.ttf"
        self.mid_width = WINDOW_WIDTH/2
        self.mid_height = WINDOW_HEIGHT/2
        # initiating the level of the game
        self.level = Level()
        # connection the client
        self.client = client
        self.client.rival_info = (self.level.rival.pos[0], self.level.rival.pos[1], 0.0, 0.0)

    def starting(self):
        for i in range(3, 0, -1):
            self.screen.fill('black')
            self.draw_text(f'{i}', 64, self.mid_width, self.mid_height)
            pygame.display.update()
            time.sleep(1)

    def run_game(self):
        """ Running the game """
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            self.screen.fill('black')
            # Communication with server
            self.client.send_udp(f"Num:{self.client.count()}; {repr(self.level.player)};;")
            self.client.communication()
            # New rival state
            pos_x, pos_y, direct_x, direct_y = self.client.rival_info
            rival_pos = (pos_x, pos_y)
            rival_direction = (direct_x, direct_y)
            # Running the level (IMPORTANT)
            self.level.run_level(rival_pos, rival_direction)
            if self.client.rival_on_flag or not self.client.rival_connected:
                break
            if self.level.player.on_flag:
                self.client.send_win()
                self.client.communication()
                break
            # updating screen
            pygame.display.update()
            self.clock.tick(FPS)
        self.end()

    def end(self):
        if not self.client.rival_connected:
            EndingMenu(True, False)
        elif self.level.player.on_flag:
            EndingMenu(True, True).run_menu()
        else:
            EndingMenu(False, True).run_menu()

    def draw_text(self, text, size, x, y):
        white = (255, 255, 255)                         # rgb for white
        pos = (x, y)                                    # center of text coordinates
        font = pygame.font.Font(self.font_name, size)
        text_surface = font.render(text, True, white)
        text_rect = text_surface.get_rect(center=pos)
        self.screen.blit(text_surface, text_rect)


class GameManagement:
    def __init__(self):
        self.starting_menu = MainMenu()
        self.client = None

    def play(self):
        game = Game(self.client)
        game.starting()
        try:
            game.run_game()
        except socket.error as err:
            print(f"error in socket {err}")
        finally:
            game.client.close()
        self.starting_menu.running = True
        self.starting_menu.client = None
        self.open_menu()
        self.play()

    def open_menu(self):
        self.starting_menu.run_menu()
        self.client = self.starting_menu.client
        WaitingMenu(self.client).run_menu()


def main():
    # Set up pygame
    pygame.init()
    pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))

    # Administrate
    admin = GameManagement()
    admin.open_menu()
    admin.play()


if __name__ == "__main__":
    main()

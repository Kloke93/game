from settings import FPS, WINDOW_HEIGHT, WINDOW_WIDTH
from client import Client
import pygame
import sys


class Menu:

    def __init__(self):
        self.running = True                        # to know when to stop the main loop
        self.screen = pygame.display.get_surface()
        self.clock = pygame.time.Clock()
        self.font_name = "Levels/graphics/GameFont.ttf"

        self.mid_width = WINDOW_WIDTH / 2
        self.mid_height = WINDOW_HEIGHT / 2
        # text
        self.display_text = []

    def run_menu(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            self.display_menu()

            pygame.display.update()     # updating screen
            self.clock.tick(FPS)

    def draw_text(self, text, size, x, y):
        white = (255, 255, 255)                         # rgb for white
        pos = (x, y)                                    # center of text coordinates
        font = pygame.font.Font(self.font_name, size)
        text_surface = font.render(text, True, white)
        text_rect = text_surface.get_rect(center=pos)
        self.screen.blit(text_surface, text_rect)

    def display_menu(self):
        self.screen.fill('black')
        for text in self.display_text:
            self.draw_text(*text)


class MainMenu(Menu):

    def __init__(self):
        super().__init__()

        self.cursor_rect = pygame.Rect(0, 0, 30, 30)
        self.offset_cursor_x = -380

        self.play_pos = self.mid_width, self.mid_height - 12
        self.play_left = 0
        self.server_text_pos = self.mid_width, self.mid_height + 124
        self.server_text_left = 0

        self.in_input = False
        self.on_play = True
        self.on_server = False
        self.move_cursor()

        self.input_bar_index = 0
        self.input_valid = (8, 46, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57)
        self.input_pos = self.mid_width - 300, self.mid_height + 260
        self.input_message = ""
        # client related
        self.client = None
        self.not_valid = ["Not valid ip entered", 20, self.mid_width, self.mid_height + 320]
        # texts
        text_title = ["My Game", 110, self.mid_width, self.mid_height - 192]
        text_play = ["Play", 62, self.play_pos[0], self.play_pos[1]]
        text_server_ip = ["Server IP", 62, self.server_text_pos[0], self.server_text_pos[1]]
        self.display_text = [text_title, text_play, text_server_ip]

    def display_menu(self):
        super().display_menu()
        self.input_bar_update()
        self.draw_input_text()
        self.move_cursor()
        self.draw_cursor()

    def run_menu(self):
        """
        Runs the main menu
        """
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    self.get_input(event.key)

            self.display_menu()

            pygame.display.update()     # updating screen
            self.clock.tick(FPS)

        try:
            self.client = Client(self.input_message)
            self.client.tcp_connect()
        except OSError:
            if isinstance(self.client, Client):
                self.client.close()
            self.display_text.append(self.not_valid)
            self.running = True
            self.run_menu()

    def press_option(self):
        if not self.in_input:
            if self.on_play:
                self.running = False
            elif self.on_server:
                self.in_input = True
                self.input_message += '|'
                if self.not_valid in self.display_text:
                    self.display_text.remove(self.not_valid)
        else:
            self.in_input = False
            self.input_message = self.input_message.replace('|', '')

    def move_cursor(self):
        if self.in_input:
            self.cursor_rect.midtop = self.mid_width + self.offset_cursor_x, self.input_pos[1]
        else:
            if self.on_play:
                self.cursor_rect.midtop = self.play_pos[0] + self.offset_cursor_x, self.play_pos[1]
            elif self.on_server:
                self.cursor_rect.midtop = self.server_text_pos[0] + self.offset_cursor_x, self.server_text_pos[1]

    def update_cursor(self, direction):
        """ Changes the state for the cursor between play and enter server"""
        if direction == "UP":
            if self.on_server:
                self.on_server = False
                self.on_play = True
        elif direction == "DOWN":
            if self.on_play:
                self.on_play = False
                self.on_server = True

    def draw_cursor(self):
        self.draw_text("-->", 30, self.cursor_rect.x, self.cursor_rect.y)

    def draw_input_text(self):
        text = self.input_message
        x, y = self.input_pos
        size = 40
        white = (255, 255, 255)  # rgb for white
        pos = (x, y)  # center of text coordinates
        font = pygame.font.Font(self.font_name, size)
        text_surface = font.render(text, True, white)
        if self.in_input:
            text_rect = text_surface.get_rect(midleft=pos)
        else:
            text_rect = text_surface.get_rect(center=(self.mid_width, self.input_pos[1]))
        self.screen.blit(text_surface, text_rect)

    def get_input(self, key):
        # input to move
        if not self.in_input:
            if key == pygame.K_w or key == pygame.K_UP:
                # up in menu
                self.update_cursor("UP")
            elif key == pygame.K_s or key == pygame.K_DOWN:
                # down in menu
                self.update_cursor("DOWN")
        # if we are receiving server ip from user check if valid first
        elif key in self.input_valid:
            self.handle_input_ip(key)
        # to activate a functionality
        if key == pygame.K_SPACE or key == pygame.K_RETURN:
            self.press_option()

    def handle_input_ip(self, key):
        # delete
        without_bar_message = self.input_message.replace('|', '')
        if key == pygame.K_BACKSPACE:
            self.input_message = without_bar_message[:-1] + '|'
        # add if messages doesn't exceed limit of characters
        elif len(without_bar_message) < 15:
            self.input_message = without_bar_message + chr(key) + '|'

    def input_bar_update(self):
        if self.in_input:
            self.input_bar_index += 1
            if self.input_bar_index >= 30:
                self.input_bar_index = 0
                if '|' in self.input_message:
                    self.input_message = self.input_message.replace('|', '')
                else:
                    self.input_message += "|"


class WaitingMenu(Menu):
    def __init__(self, client):
        """
        Creating waiting menu
        :param client: Client for waiting connection
        :type client: Client
        """
        super().__init__()
        self.waiting_text = "Waiting for another player"
        self.waiting_pos = 150, self.mid_height
        self.waiting_index = 0
        self.client = client

    def draw_waiting(self):
        text = self.waiting_text
        x, y = self.waiting_pos
        size = 36
        white = (255, 255, 255)  # rgb for white
        pos = (x, y)             # center of text coordinates
        font = pygame.font.Font(self.font_name, size)
        text_surface = font.render(text, True, white)
        text_rect = text_surface.get_rect(midleft=pos)
        self.screen.blit(text_surface, text_rect)

    def animate_waiting(self):
        self.waiting_index += 1
        if self.waiting_index >= 42:
            if self.waiting_text.count('.') < 3:
                self.waiting_text += '.'
            else:
                self.waiting_text = self.waiting_text.replace('.', '')
            self.waiting_index = 0
        self.draw_waiting()

    def run_menu(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
            self.client.communication()
            if self.client.started:
                self.running = False
            self.display_menu()
            self.animate_waiting()

            pygame.display.update()     # updating screen
            self.clock.tick(FPS)


class EndingMenu(Menu):
    def __init__(self, has_won, connected):
        super().__init__()
        if not connected:
            text_disconnection = ["Rival disconnected", 32, self.mid_width, self.mid_height - 320]
            self.display_text += [text_disconnection]
        if has_won:
            text_end = ["You won!!", 86, self.mid_width, self.mid_height]
        else:
            text_end = ["You lost...", 86, self.mid_width, self.mid_height]
        text_exit = ["Press space to return to menu", 32, self.mid_width, self.mid_height + 320]
        self.display_text += [text_end, text_exit]

    def run_menu(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                    self.running = False

            self.display_menu()

            pygame.display.update()     # updating screen
            self.clock.tick(FPS)

    def display_menu(self):
        for text in self.display_text:
            self.draw_text(*text)



"""
Author: Tomas Dal Farra
"""
import socket
import select


class Client:
    server_port = 53679
    max_buffer = 1024

    def __init__(self, ip):
        # server ip
        self.server_ip = ip
        self.server_address = (self.server_ip, Client.server_port)
        # socket opening
        tcp_client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        udp_client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        udp_client.bind(("0.0.0.0", Client.server_port + 1))
        udp_client.setblocking(False)

        self.open_clients = [tcp_client, udp_client]
        self.send_clients = []
        self.message_udp = []
        self.message_tcp = []
        self.num = -1                                    # For sending udp order (initializing)
        # For game store rival information
        self.started = False
        self.rival_info = [None, None, None, None]
        self.rival_num = -1
        self.rival_on_flag = False
        self.rival_connected = True

    def tcp_connect(self):
        """
        connects the socket tcp of the client to the server
        :return: None
        """
        self.open_clients[0].connect(self.server_address)
        self.open_clients[0].setblocking(False)
        print("Client Connected")

    def send_udp(self, message):
        """
        Adds message to message udp list
        :param message: Message to send
        :return: None
        """
        if self.started:
            self.message_udp.append(message)

    def send_win(self):
        self.send_clients.append(self.open_clients[0])
        self.message_tcp.append('End;;')

    def count(self):
        """ Num for ordering udp messages """
        self.num += 1
        return self.num

    @staticmethod
    def validate_udp(message):
        """
        Checks if message udp has the correct protocol to validate it
        and return the important data (num, pos, direction)
        :param message: message to validate and extract info
        :type message: str
        :return: if message is valid returns list with [num, pos_x, pos_y, direction_x, direction_y]
        else return list with [False]
        :rtype: list
        """
        data = []
        message_split = message.split(';')
        # Checks protocol words
        if len(message_split) != 5:
            return None
        elif message_split[0][:4] != "Num:":
            return None
        elif (message_split[1][:13] != " Player(pos:(") or (message_split[1][-1] != ')'):
            return None
        elif (message_split[2][:12] != " direction:(") or (message_split[2][-2:] != "))"):
            return None
        elif (',' not in message_split[1]) or (',' not in message_split[2]):
            return None
        elif message_split[3] != '' or message_split[4] != '':
            return None
        a, b = message_split[1].index(','), message_split[2].index(',')
        # Checks for valid numbers and extract them
        try:
            # Num
            data.append(int(message_split[0][4:]))
            # pos x
            data.append(int(message_split[1][13: a]))
            # pos y
            data.append(int(message_split[1][a + 2:-1]))
            # direction x
            data.append(float(message_split[2][12: b]))
            # direction y
            data.append(float(message_split[2][b + 2:-2]))
        except ValueError:
            return None
        return data

    def start(self, start_message):
        """ If message is start message as start game """
        if start_message == "Start;;":
            self.send_clients.append(self.open_clients[1])
            self.started = True
            self.message_udp.clear()

    def end(self, end_message):
        if end_message == "End;;":
            self.rival_on_flag = True
        elif end_message == "Disconnected;;":
            self.rival_connected = False

    def communication(self):
        """
        Communicates the client with the server
        :return: None
        """
        rlist, wlist, xlist = select.select(self.open_clients, self.send_clients, self.open_clients, 0.005)

        for s in xlist:
            print(f'there is an exception in {s}')
            raise socket.error

        # to read
        for s in rlist:
            if s == self.open_clients[1]:
                # Udp communication until buffer is empty
                data, _ = s.recvfrom(Client.max_buffer)
                # to empty the buffer
                in_buffer = True
                while in_buffer:
                    try:
                        data, _ = s.recvfrom(Client.max_buffer)
                    except OSError:
                        in_buffer = False
                info = self.validate_udp(data.decode())
                if (info is not None) and (info[0] > self.rival_num):
                    # Checks if packet is able to use
                    self.rival_num = info[0]
                    self.rival_info = info[1:]
            else:
                data = s.recv(Client.max_buffer).decode()
                self.start(data)
                self.end(data)

        # to write
        for message in self.message_udp:
            # if there is a message to send (udp)
            if self.send_clients[0] in wlist:
                self.send_clients[0].sendto(message.encode(), self.server_address)
                self.message_udp.remove(message)
        for message in self.message_tcp:
            if self.send_clients[1] in wlist:
                self.send_clients[1].send(message.encode())
                self.message_tcp.remove(message)
            pass

    def close(self):
        """ Closes all sockets """
        for client in self.open_clients:
            client.close()

<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="WindowLight" tilewidth="192" tileheight="192" tilecount="1" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="192" height="192" source="../../../../OneDrive/Escritorio/Levels/graphics/Window/window light/01.png"/>
 </tile>
</tileset>

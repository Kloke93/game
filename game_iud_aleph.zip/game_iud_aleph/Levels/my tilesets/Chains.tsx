<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="Chains" tilewidth="64" tileheight="128" tilecount="16" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="64" height="128" source="../graphics/Chains/Big Chain/01.png"/>
 </tile>
 <tile id="1">
  <image width="64" height="128" source="../graphics/Chains/Big Chain/02.png"/>
 </tile>
 <tile id="2">
  <image width="64" height="128" source="../graphics/Chains/Big Chain/03.png"/>
 </tile>
 <tile id="3">
  <image width="64" height="128" source="../graphics/Chains/Big Chain/04.png"/>
 </tile>
 <tile id="4">
  <image width="64" height="128" source="../graphics/Chains/Big Chain/05.png"/>
 </tile>
 <tile id="5">
  <image width="64" height="128" source="../graphics/Chains/Big Chain/06.png"/>
 </tile>
 <tile id="6">
  <image width="64" height="128" source="../graphics/Chains/Big Chain/07.png"/>
 </tile>
 <tile id="7">
  <image width="64" height="128" source="../graphics/Chains/Big Chain/08.png"/>
 </tile>
 <tile id="8">
  <image width="64" height="64" source="../graphics/Chains/Small Chain/01.png"/>
 </tile>
 <tile id="9">
  <image width="64" height="64" source="../graphics/Chains/Small Chain/02.png"/>
 </tile>
 <tile id="10">
  <image width="64" height="64" source="../graphics/Chains/Small Chain/03.png"/>
 </tile>
 <tile id="11">
  <image width="64" height="64" source="../graphics/Chains/Small Chain/04.png"/>
 </tile>
 <tile id="12">
  <image width="64" height="64" source="../graphics/Chains/Small Chain/05.png"/>
 </tile>
 <tile id="13">
  <image width="64" height="64" source="../graphics/Chains/Small Chain/06.png"/>
 </tile>
 <tile id="14">
  <image width="64" height="64" source="../graphics/Chains/Small Chain/07.png"/>
 </tile>
 <tile id="15">
  <image width="64" height="64" source="../graphics/Chains/Small Chain/08.png"/>
 </tile>
</tileset>

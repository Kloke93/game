from pytmx.util_pygame import load_pygame


# Basic settings
TILE_SIZE = 64
WINDOW_WIDTH = 1280
WINDOW_HEIGHT = 720
FPS = 60
TILE_LAYERS = ("Background", "Terrain")

# Camera
CAMERA_BORDERS = {
    'left': 320,
    'right': 320,
    'top': 150,
    'bottom': 150
                 }


# Level 1
def level_1():
    return load_pygame("Levels/MapGameTiles.tmx")

<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="ShipTileBackGround" tilewidth="64" tileheight="64" tilecount="247" columns="19">
 <image source="../graphics/Terrain and Back Wall (64x64).png" width="1216" height="832"/>
</tileset>

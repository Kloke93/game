""" Support for simplify """
import pygame
from os import walk


def import_folder(path):
    """
    Imports all images in folder
    :param path: Path to folder
    :type path: str
    :return: All the images imported
    :rtype: list
    """
    surfaces = []
    for _, __, img_file in walk(path):
        for image in img_file:
            full_path = path + '/' + image
            image_surf = pygame.image.load(full_path).convert_alpha()
            surfaces.append(image_surf)
    return surfaces

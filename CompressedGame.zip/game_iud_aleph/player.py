# Player class
# For gravity we want it to increase with the fall, so we add to direction +=  gravity and then y += direction,
# this way direction that indicates movement of our player is increasing, and we are also increasing y
import pygame
from spritesheet import SpriteSheet
from support import import_folder
from particles import ParticleEffect


class Player(pygame.sprite.Sprite):

    def __init__(self, member_groups, collision_sprites, pos, surface):
        self.member_groups = member_groups
        super().__init__(member_groups)
        # Animation mechanics
        self.animations = {'idle': [], 'run': [], 'jump': [], 'fall': []}     # Will be filled in the child classes
        self.image = None                                                     # Also, will be filled in child classes
        self.frame_index = 0
        self.animation_speed = 0.20
        # Dust particles
        self.dust_run = self.import_particles_run()
        self.dust_frame_index = 0
        self.dust_animation_speed = 0.20
        self.display_surface = surface                        # So particles can be drawn in the background
        self.camera_offset = None                             # Because of the camera offset to draw in the right place
        # Player movement
        self.pos = pos
        self.direction = pygame.math.Vector2()
        self.speed = 8
        self.gravity = 0.8
        self.jump_speed = 16
        self.collision_sprites = collision_sprites
        # Player state
        self.state = 'idle'
        self.facing_right = True
        self.on_ground = False
        self.on_ceiling = False
        self.on_left = False
        self.on_right = False
        self.current_x = 0

    @staticmethod
    def import_particles_run():
        """ Imports all running particles """
        return [pygame.transform.scale(image, (image.get_width() * 1.8, image.get_height() * 1.8))
                for image in import_folder("Levels/graphics/Dust Particles/Run")]

    def create_jump_particles(self, pos):
        """ Creating the jump particles sprite """
        pos -= pygame.math.Vector2(0, 12)
        ParticleEffect(self.member_groups, pos, "jump")

    def create_land_particles(self, pos):
        pos -= pygame.math.Vector2(0, 16)
        ParticleEffect(self.member_groups, pos, "land")

    def animate(self):
        animation = self.animations[self.state]
        # loop over frame index
        self.frame_index += self.animation_speed
        if self.frame_index >= len(animation):
            self.frame_index = 0

        image = animation[int(self.frame_index)]
        if self.facing_right:
            self.image = image
        else:
            flipped_image = pygame.transform.flip(image, True, False)
            self.image = flipped_image
        # set the rect
        if self.on_ground and self.on_right:
            self.rect = self.image.get_rect(bottomright=self.rect.bottomright)
        elif self.on_ground and self.on_right:
            self.rect = self.image.get_rect(bottomleft=self.rect.bottomleft)
        elif self.on_ground:
            self.rect = self.image.get_rect(midbottom=self.rect.midbottom)
        elif self.on_ceiling and self.on_right:
            self.rect = self.image.get_rect(topright=self.rect.topright)
        elif self.on_ceiling and self.on_right:
            self.rect = self.image.get_rect(topleft=self.rect.topleft)
        elif self.on_ceiling:
            self.rect = self.image.get_rect(midtop=self.rect.midtop)

    def run_dust_animation(self):
        # Moving forward the index for the animation
        if self.state == "run" and self.on_ground:
            self.dust_frame_index += self.dust_animation_speed
            if self.dust_frame_index >= len(self.dust_run):
                self.dust_frame_index = 0
            # selecting the corresponding particle
            dust_particle = self.dust_run[int(self.dust_frame_index)]
            #  Drawing particles to the display surface
            if self.facing_right:
                pos = self.rect.bottomleft - self.camera_offset - pygame.math.Vector2(34, 36)
                self.display_surface.blit(dust_particle, pos)
            else:
                pos = self.rect.bottomright - self.camera_offset - pygame.math.Vector2(56, 36)
                flipped_dust_particle = pygame.transform.flip(dust_particle, True, False)
                self.display_surface.blit(flipped_dust_particle, pos)
        else:
            self.dust_frame_index = 0

    def get_state(self):
        if self.direction.y < 0:
            self.state = 'jump'
        elif self.direction.y > 1:   # direction.y has to be greater than gravity but smaller than twice its value
            self.state = 'fall'
        else:
            if self.direction.x != 0:
                self.state = 'run'
            else:
                self.state = 'idle'

    def get_input(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_d] and keys[pygame.K_a]:
            self.direction.x = 0
        elif keys[pygame.K_d]:
            self.direction.x = 1
            self.facing_right = True
        elif keys[pygame.K_a]:
            self.direction.x = -1
            self.facing_right = False
        else:
            self.direction.x = 0
        # jumping
        if keys[pygame.K_SPACE] and self.on_ground:
            self.jump()
            self.create_jump_particles(self.rect.midbottom)
            self.on_ground = False

    def horizontal_collision(self):
        for sprite in self.collision_sprites.sprites():
            if sprite.rect.colliderect(self.rect):
                if self.direction.x < 0:
                    self.rect.left = sprite.rect.right
                    self.on_left = True
                    self.current_x = self.rect.left
                elif self.direction.x > 0:
                    self.rect.right = sprite.rect.left
                    self.on_right = True
                    self.current_x = self.rect.right
        if self.on_left and (self.rect.left < self.current_x or self.direction.x >= 0):
            self.on_left = False
        if self.on_right and (self.rect.right > self.current_x or self.direction.x <= 0):
            self.on_right = False

    def vertical_collision(self):
        for sprite in self.collision_sprites.sprites():
            if sprite.rect.colliderect(self.rect):
                if self.direction.y > 0:
                    self.rect.bottom = sprite.rect.top
                    self.direction.y = 0
                    self.on_ground = True
                elif self.direction.y < 0:
                    self.rect.top = sprite.rect.bottom
                    self.direction.y = 0
                    self.on_ceiling = True
        if self.on_ground and (self.direction.y < 0 or self.direction.y > 1):
            self.on_ground = False
        if self.on_ceiling and self.direction.y > 0:
            self.on_ceiling = False

    def move(self):
        # horizontal movement and collision
        self.rect.x += self.direction.x * self.speed
        self.horizontal_collision()
        # vertical movement and collision
        self.apply_gravity()
        was_on_ground = self.on_ground
        fall = self.direction.y
        self.vertical_collision()
        if (fall > 12) and (not was_on_ground and self.on_ground):
            self.create_land_particles(self.rect.midbottom)

    def apply_gravity(self):
        self.direction.y += self.gravity
        self.rect.y += self.direction.y

    def jump(self):
        self.direction.y = -self.jump_speed

    def update(self,  *args):
        # Updating the player
        self.get_input()
        self.get_state()
        self.animate()
        self.run_dust_animation()
        self.move()

    def __repr__(self):
        return f"Player(pos:{self.pos}; direction:({self.direction.x}, {self.direction.y}))"


class PlayerFrog(Player):

    def __init__(self, member_groups, collision_sprites, pos, surface):
        super().__init__(member_groups, collision_sprites, pos, surface)
        self.animations = self.animation_dict_import()
        self.image = self.animations[self.state][self.frame_index]
        self.rect = self.image.get_rect(topleft=pos)

    @staticmethod
    def animation_dict_import():
        """
        With the path to the sheet sprite images, loads all the sheets and
         gets the individual images for each action in a dictionary
        :return: dictionary of the different states of the player with a list of images for each one
        :rtype: dict
        """
        animations = {'idle': [], 'run': [], 'jump': [], 'fall': []}
        scale_index = 2     # For scaling the images
        # Animation paths
        idle_path = "Levels/graphics/Main Characters/Ninja Frog/Idle (32x32).png"
        run_path = "Levels/graphics/Main Characters/Ninja Frog/Run (32x32).png"
        jump_path = "Levels/graphics/Main Characters/Ninja Frog/Jump (32x32).png"
        fall_path = "Levels/graphics/Main Characters/Ninja Frog/Fall (32x32).png"
        # Animation sheets
        idle_sheet = SpriteSheet(idle_path, True)
        run_sheet = SpriteSheet(run_path, True)
        jump_sheet = SpriteSheet(jump_path, True)
        fall_sheet = SpriteSheet(fall_path, True)
        # jump and fall are both single images
        # Completing dictionary
        animations['idle'] = idle_sheet.load_grid_images(
            1, 11, 4, x_padding=9, y_margin_top=6, y_margin_bottom=0, scale_index=scale_index, colorkey=-1)
        # Because lack of symmetry we need to do many rectangles for run
        rects_run = [
            (4, 4, 23, 28), (36, 4, 23, 28), (68, 4, 23, 28), (100, 4, 23, 28), (131, 4, 25, 28), (163, 4, 25, 28),
            (196, 4, 24, 28), (228, 4, 24, 28), (260, 4, 24, 28), (292, 4, 24, 28), (323, 4, 25, 28), (355, 4, 25, 28)
        ]
        animations['run'] = run_sheet.images_at(rects_run, -1, scale_index)
        jump_image = jump_sheet.image_at((4, 4, 23, 28), -1, scale_index)
        fall_image = fall_sheet.image_at((4, 6, 24, 26), -1, scale_index)
        animations['jump'].append(jump_image)
        animations['fall'].append(fall_image)
        return animations


# To Revise
class PlayerPink(Player):
    def __init__(self, member_groups, collision_sprites, pos, surface):
        super().__init__(member_groups, collision_sprites, pos, surface)
        self.animations = self.animation_dict_import()
        self.image = self.animations[self.state][self.frame_index]
        self.rect = self.image.get_rect(topleft=pos)

    @staticmethod
    def animation_dict_import():
        """ Imports all images for the character """
        animations = {'idle': [], 'run': [], 'jump': [], 'fall': []}
        scale_index = 2  # For scaling the images
        # Animation paths
        idle_path = "Levels/graphics/Main Characters/Pink Man/Idle (32x32).png"
        run_path = "Levels/graphics/Main Characters/Pink Man/Run (32x32).png"
        jump_path = "Levels/graphics/Main Characters/Pink Man/Jump (32x32).png"
        fall_path = "Levels/graphics/Main Characters/Pink Man/Fall (32x32).png"
        # Animation sheets
        idle_sheet = SpriteSheet(idle_path, True)
        run_sheet = SpriteSheet(run_path, True)
        jump_sheet = SpriteSheet(jump_path, True)
        fall_sheet = SpriteSheet(fall_path, True)
        # jump and fall are both single images
        # Completing dictionary
        animations['idle'] = idle_sheet.load_grid_images(
            1, 11, 4, x_padding=9, y_margin_top=6, y_margin_bottom=0, scale_index=scale_index, colorkey=-1)
        # Because lack of symmetry we need to do many rectangles for run
        rects_run = [
            (4, 4, 23, 28), (36, 4, 23, 28), (68, 4, 23, 28), (100, 4, 23, 28), (131, 4, 25, 28), (163, 4, 25, 28),
            (196, 4, 24, 28), (228, 4, 24, 28), (260, 4, 24, 28), (292, 4, 24, 28), (323, 4, 25, 28), (355, 4, 25, 28)
        ]
        animations['run'] = run_sheet.images_at(rects_run, -1, scale_index)
        jump_image = jump_sheet.image_at((4, 4, 23, 28), -1, scale_index)
        fall_image = fall_sheet.image_at((4, 6, 24, 26), -1, scale_index)
        animations['jump'].append(jump_image)
        animations['fall'].append(fall_image)
        return animations


class RivalFrog(PlayerFrog):
    def __init__(self, member_groups, collision_sprites, pos, surface):
        super().__init__(member_groups, collision_sprites, pos, surface)

    def update(self, pos, direction):
        """ Custom update method for rival """
        self.get_state()
        self.animate()
        self.run_dust_animation()
        if (self.direction.y >= 0) and (direction[1] < 0):
            self.create_jump_particles(self.rect.midbottom)
            self.on_ground = False
        self.rect.x, self.rect.y = pos
        if (self.direction.y > 12) and (direction[1] <= 0):
            self.create_land_particles(self.rect.midbottom)
        if (self.direction.y > 0) and (direction[1] <= 0):
            self.on_ground = True
        self.direction.x = direction[0]
        self.direction.y = direction[1]
        if direction[0] == 1:
            self.facing_right = True
        elif direction[0] == -1:
            self.facing_right = False

"""
Author: Tomas Dal Farra
Date:
Description:
"""
import socket
import pygame
import sys
from settings import WINDOW_WIDTH, WINDOW_HEIGHT, FPS
from level import Level
from menu import MainMenu, WaitingMenu


class Game:
    def __init__(self, client):
        """ Game and client setup """
        pygame.display.set_caption('Happy Toad')
        self.screen = pygame.display.get_surface()
        self.clock = pygame.time.Clock()
        # initiating the level of the game
        self.level = Level()
        # connection the client
        self.client = client
        self.client.rival_info = (self.level.rival.pos[0], self.level.rival.pos[1], 0.0, 0.0)

    def run_game(self):
        """ Running the game """
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            self.screen.fill('black')
            # Communication with server
            self.client.send_udp(f"Num:{self.client.count()}; {repr(self.level.player)};;")
            self.client.communication()
            # New rival state
            pos_x, pos_y, direct_x, direct_y = self.client.rival_info
            rival_pos = (pos_x, pos_y)
            rival_direction = (direct_x, direct_y)
            # Running the level (IMPORTANT)
            self.level.run_level(rival_pos, rival_direction)
            # updating screen
            pygame.display.update()
            self.clock.tick(FPS)


def play(client):
    game = Game(client)
    try:
        game.run_game()
    except socket.error as err:
        print(f"error in socket {err}")
    finally:
        game.client.close()


def open_menu():
    starting_menu = MainMenu()
    starting_menu.run_menu()
    client = starting_menu.client
    WaitingMenu(client).run_menu()
    return client


def main():
    # Set up pygame
    pygame.init()
    pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))

    # play()
    client = open_menu()
    play(client)


if __name__ == "__main__":
    main()

"""
Author: Tomas Dal Farra
Date:
Description:
"""
import pygame
from support import import_folder
from random import randint


class Tile(pygame.sprite.Sprite):

    def __init__(self, pos, surface, member_groups):
        super().__init__(member_groups)
        self.image = surface
        self.rect = self.image.get_rect(topleft=pos)


class AnimatedTile(Tile):
    def __init__(self, pos, surface, member_groups, frames):
        super().__init__(pos, surface, member_groups)
        self.frames = frames
        self.frame_index = randint(0, 6)

    def animate(self):
        self.frame_index += 0.20
        if self.frame_index >= len(self.frames):
            self.frame_index = 0
        self.image = self.frames[int(self.frame_index)]

    def update(self, *args):
        self.animate()


class Door(Tile):
    def __init__(self, pos, surface, member_groups):
        super().__init__(pos, surface, member_groups)
        self.frames = import_folder("Levels/graphics/Door")
        self.frame_index = 0
        self.image = self.frames[self.frame_index]

    def animate(self):
        self.frame_index += 0.20
        if self.frame_index >= len(self.frames):
            active_group = self.groups()[1]
            self.remove(active_group)
        else:
            self.image = self.frames[int(self.frame_index)]

    def update(self, *args):
        self.animate()

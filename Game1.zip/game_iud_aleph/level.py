"""
Author: Tomas Dal Farra
Date:
Description:
"""
import pygame
from tiles import Tile, AnimatedTile, Door
from player import PlayerFrog, RivalFrog
from settings import level_1, TILE_SIZE, CAMERA_BORDERS, TILE_LAYERS
from support import import_folder


class Level:

    def __init__(self):
        # Level setup
        self.player = None
        self.rival = None  # Check if needed
        self.display_surface = pygame.display.get_surface()
        # Sprite group setup
        self.visible_sprites = CameraGroup()
        self.active_sprites = pygame.sprite.Group()
        self.collision_sprites = pygame.sprite.Group()
        # Important to go after the rest of the setup
        self.all_frames = {}
        self.import_graphics()
        self.setup_level_1()

    def import_graphics(self):
        """ Imports all images for the map graphs """
        path = "Levels/graphics/"
        self.all_frames["Window"] = import_folder(path + "Window/window")
        self.all_frames["Window"] = [pygame.transform.scale(frame, (64, 64)) for frame in self.all_frames["Window"]]
        self.all_frames["big chains"] = import_folder(path + "Chains/Big Chain")
        self.all_frames["small chains"] = import_folder(path + "Chains/Small Chain")
        self.all_frames["Candle"] = import_folder(path + "Candle/Candle")
        self.all_frames["CandleLight"] = import_folder(path + "Candle/Candle Light")
        self.all_frames["Flag"] = import_folder(path + "Flag")

    def setup_level_1(self):
        """ Set-up of the level putting all tiles in their place """
        for layer in level_1().layers:
            if layer.name in TILE_LAYERS:
                for x, y, surf in layer.tiles():
                    pos = (x * TILE_SIZE, y * TILE_SIZE)
                    if layer.name == TILE_LAYERS[0]:
                        Tile(pos, surf, [self.visible_sprites])
                    else:
                        Tile(pos, surf, [self.visible_sprites, self.collision_sprites])
            else:
                for obj in layer:
                    if layer.name == "Chains":
                        if obj.name == "Big":
                            AnimatedTile((obj.x, obj.y), obj.image,
                                         [self.visible_sprites, self.active_sprites], self.all_frames["big chains"])
                        else:
                            AnimatedTile((obj.x, obj.y), obj.image,
                                         [self.visible_sprites, self.active_sprites], self.all_frames["small chains"])
                    elif layer.name in ["Candle", "CandleLight", "Window", "Flag"]:
                        AnimatedTile((obj.x, obj.y), obj.image,
                                     [self.visible_sprites, self.active_sprites], self.all_frames[layer.name])
                    elif layer.name == "Door":
                        Door((obj.x, obj.y), obj.image,
                             [self.visible_sprites, self.active_sprites])
                    else:
                        Tile((obj.x, obj.y), obj.image, [self.visible_sprites])
        # Player and rival initiation
        self.player = PlayerFrog(
                         [self.visible_sprites, self.active_sprites], self.collision_sprites, (400, 400),
                         self.display_surface)
        self.rival = RivalFrog(
                         [self.visible_sprites, self.active_sprites], None, (360, 400), self.display_surface)

    def run_level(self, pos, direction):
        """
        Runs the level
        1) Update active sprites
        2) Updates position of player (not to draw it because that depends on the rect but to send it to the rival)
        3) Draws visible sprites based on offset of my camera (CameraGroup)
        4) offset for rival
        :param pos: Position of the rival
        :param direction: Direction of the rival
        :return: None
        """
        self.visible_sprites.custom_draw(self.player)
        self.rival.camera_offset = self.visible_sprites.offset
        self.active_sprites.update(pos, direction)
        self.player.pos = self.player.rect.topleft


class CameraGroup(pygame.sprite.Group):

    def __init__(self):
        """ Constructing the camera group """
        super().__init__()
        self.display_surface = pygame.display.get_surface()
        cam_left = CAMERA_BORDERS['left']
        cam_top = CAMERA_BORDERS['top']
        cam_width = self.display_surface.get_size()[0] - (cam_left + CAMERA_BORDERS['right'])
        cam_height = self.display_surface.get_size()[1] - (cam_top + CAMERA_BORDERS['bottom'])
        self.camera_rect = pygame.rect.Rect(cam_left, cam_top + 100, cam_width, cam_height)
        self.offset = None

    def custom_draw(self, player):
        """ Drawing sprites based in the offset of the player with the camera rectangle """
        # get the camera pos
        if player.rect.left < self.camera_rect.left:
            self.camera_rect.left = player.rect.left
        if player.rect.right > self.camera_rect.right:
            self.camera_rect.right = player.rect.right
        if player.rect.top < self.camera_rect.top:
            self.camera_rect.top = player.rect.top
        if player.rect.bottom > self.camera_rect.bottom:
            self.camera_rect.bottom = player.rect.bottom
        self.offset = pygame.math.Vector2(
            self.camera_rect.left - CAMERA_BORDERS['left'],
            self.camera_rect.top - CAMERA_BORDERS['top'])
        for sprite in self.sprites():
            offset_pos = sprite.rect.topleft - self.offset
            player.camera_offset = self.offset

            self.display_surface.blit(sprite.image, offset_pos)

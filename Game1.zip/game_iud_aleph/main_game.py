"""
Author: Tomas Dal Farra
Date:
Description:
"""
import socket

import pygame
import sys
from settings import WINDOW_WIDTH, WINDOW_HEIGHT, FPS
from level import Level
from client import Client


class Game:

    def __init__(self):
        """ Game and client setup """
        pygame.init()
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption('My game')
        self.clock = pygame.time.Clock()
        # initiating the level of the game
        self.level = Level()
        # connection the client
        self.client = Client()
        # self.client.tcp_connect()
        self.client.rival_info = (self.level.rival.pos[0], self.level.rival.pos[1], 0.0, 0.0)

    def run_game(self):
        """ Running the game """
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            self.screen.fill('black')
            # Communication with server
            # self.client.send_udp(f"Num:{self.client.count()}; {repr(self.level.player)};;")
            # self.client.communication()
            # New rival state
            pos_x, pos_y, direct_x, direct_y = self.client.rival_info
            rival_pos = (pos_x, pos_y)
            rival_direction = (direct_x, direct_y)
            # Running the level (IMPORTANT)
            self.level.run_level(rival_pos, rival_direction)
            # updating screen
            pygame.display.update()
            self.clock.tick(FPS)


def play():
    game = Game()
    try:
        game.run_game()
    except socket.error as err:
        print(f"error in socket {err}")
    finally:
        game.client.close()


def menu():
    pass


def main():
    play()


if __name__ == "__main__":
    main()

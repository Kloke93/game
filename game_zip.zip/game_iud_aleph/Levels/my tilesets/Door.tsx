<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="Door" tilewidth="128" tileheight="128" tilecount="5" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="128" height="128" source="../graphics/Door/01.png"/>
 </tile>
 <tile id="1">
  <image width="128" height="128" source="../graphics/Door/02.png"/>
 </tile>
 <tile id="2">
  <image width="128" height="128" source="../graphics/Door/03.png"/>
 </tile>
 <tile id="3">
  <image width="128" height="128" source="../graphics/Door/04.png"/>
 </tile>
 <tile id="4">
  <image width="128" height="128" source="../graphics/Door/05.png"/>
 </tile>
</tileset>
